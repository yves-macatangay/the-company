<?php

require "Database.php";

class User extends Database {

    public function createUser($first_name, $last_name, $username, $password){

        $sql = "INSERT INTO users(first_name, last_name, username, password) 
        VALUES('$first_name', '$last_name', '$username', '$password')";

        if($this->conn->query($sql)){
            //go to login page
            header("location: ../views");
            exit;
        }else{
            die("Error creating user: ".$this->conn->error);
        }
    }

    public function login($username, $password){

        //finding the user
        $sql = "SELECT * FROM users WHERE username='$username'";

        $result = $this->conn->query($sql);

        if($result->num_rows == 1){ // if 1 user record found
            $user_data = $result->fetch_assoc();
            //check password
            if(password_verify($password, $user_data['password'])){
                //login
                session_start();
                $_SESSION['user_id'] = $user_data['id'];
                $_SESSION['username'] = $user_data['username'];
                //go to dashboard page
                header("location: ../views/dashboard.php");
                exit;
            }else{
                die("Incorrect password");
            }
        }else{
            die("User not found.");
        }
    }

    public function getAllUsers(){
        $sql = "SELECT * FROM users";

        if($result = $this->conn->query($sql)){
            return $result; //return or pass back the data
        }else{
            die("Error retrieving users: ". $this->conn->error);
        }
    }
}